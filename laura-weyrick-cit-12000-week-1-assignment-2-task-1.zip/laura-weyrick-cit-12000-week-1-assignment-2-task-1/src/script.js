var prompts = prompt("What is your name?");
var prompted = prompt("What is your favorite candy?");
var prompts2 = prompt("What is your name?");               
var prompted2 =prompt("What is your favorite candy?");       
                      
var greeting = "Hello, my name is "+prompts;
var greeted = "My favorite candy is "+prompted;                                                         var greets = "Hello, my name is " +prompts2;     
var greety = "My least favorite candy is "+prompted2;
var person ="Wendy";
var candy ="sugar";

function writeHTML(name, className){
  document.querySelector(className).innerHTML = "Hi! My name is "+prompts+" and my favorite candy is "+prompted+". ";
  document.querySelector(className).innerHTML = "Hi, the name is "+prompts2+" and "+prompted2+" is terrible! ";
  person=name;
}

document.querySelector(".words").innerHTML = greeting;
document.querySelector(".candy").innerHTML = greeted;
document.querySelector(".multiple").innerHTML = greets;
document.querySelector(".candies").innerHTML = greety;


writeHTML("Lynette", ".person1");
writeHTML("Lynette", ".person1");
writeHTML("Laura", ".person2");
writeHTML("Laura", ".person2");