var num = 12;
var stringNum = 34;

num = num+Number(stringNum);

document.querySelector(".num").innerHTML = num;